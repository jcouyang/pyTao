#!/usr/bin/python

from taobaoapi2 import *
from Tkinter import *
import ttk
from zxing import *

zxing_location = "./zxing/"
testimage = "sample.png"
containerUrl = ''
root = Tk()

root.title ='taobao helper'


# Initialize our country "databases":
#  - the list of country codes (a subset anyway)
#  - a parallel list of country names, in the same order as the country codes
#  - a hash table mapping country code to population<
countrycodes = ('ar', 'au', 'be', 'br', 'ca', 'cn', 'dk', 'fi', 'fr', 'gr', 'in', 'it', 'jp', 'mx', 'nl', 'no', 'es', 'se', 'ch')
##countrynames = ('Argentina', 'Australia', 'Belgium', 'Brazil', 'Canada', 'China', 'Denmark', \
##        'Finland', 'France', 'Greece', 'India', 'Italy', 'Japan', 'Mexico', 'Netherlands', 'Norway', 'Spain', \
##        'Sweden', 'Switzerland')
#cnames = StringVar(value=countrynames)
countrynames=[]
populations = {'ar':41000000, 'au':21179211, 'be':10584534, 'br':185971537, \
        'ca':33148682, 'cn':1323128240, 'dk':5457415, 'fi':5302000, 'fr':64102140, 'gr':11147000, \
        'in':1131043000, 'it':59206382, 'jp':127718000, 'mx':106535000, 'nl':16402414, \
        'no':4738085, 'es':45116894, 'se':9174082, 'ch':7508700}

# Names of the gifts we can send
gifts = { 'card':'Greeting card', 'flowers':'Flowers', 'nastygram':'Nastygram'}

# State variables
gift = StringVar()
sentmsg = StringVar()
statusmsg = StringVar()

# Taobao bussinuss
itemSold = TradesSoldGet()
itemSold.setParams(session='61016030690140e08c8bb81db0f6b6fb7392ef331925e02180020093',status='WAIT_SELLER_SEND_GOODS')
itemSold.fetch()
data = itemSold.datas

deliveryCompany = CompaniesGet()
deliveryCompany.fetch()
companies = deliveryCompany.datas
#print deliveryCompany.datas


# Show item detail
def showDetail(*args):
    idxs = lbox.curselection()
    if len(idxs)==1:
        idx = int(idxs[0])
        code = countrycodes[idx]
        name = countrynames[idx]
        popn = populations[code]
        statusmsg.set("The population of %s (%s) is %d" % (name, code, popn))
    sentmsg.set('')

# scan barcode
def scanBarcode(*args):
    idxs = lbox.curselection()
    if len(idxs)==1:
        idx = int(idxs[0])
        lbox.see(idx)
        name = countrynames[idx]
        # Gift sending left as an exercise to the reader
        sentmsg.set("Sent %s to leader of %s" % (gifts[gift.get()], name))

# Create and grid the outer content frame
c = ttk.Frame(root, padding=(5, 5, 12, 0))
c.grid(column=0, row=1, sticky=(N,W,E,S))
root.grid_columnconfigure(0, weight=1)
root.grid_rowconfigure(0,weight=1)

sercetCode = StringVar()
sercetCode.set('sandbox6881dbe428ca0c26422cf2487')
api_key =  StringVar()
api_key.set('12408725')


# auth_url = 'http://container.api.tbsandbox.com/container?appkey=%s' % api_key
# taobao_url ='http://gw.api.tbsandbox.com/router/rest'
# sign = 'slFDafsWNuIC5UyIw03hkA%3D%3D'

scEntry = ttk.Entry(c,width=60, textvariable=sercetCode)
scEntry.grid(column=0,row=0, sticky=W)
ttk.Entry(c,width=20, textvariable=api_key).grid(column=0,row=0)


def setApi(*args):
    base.sercetCode = sercetCode.get()
    base.api_key=api_key.get()
    print base.sercetCode
    urlopen = urllib2.urlopen(containerUrl,api_key.get())
    
Button(c, text="set", command=setApi).grid(column=1, row=0)



# Create the different widgets; note the variables that many
# of them are bound to, as well as the button callback.
# Note we're using the StringVar() 'cnames', constructed from 'countrynames'
lbox = Listbox(c, height=5)

deliveryComp = StringVar()
deliveryComp.set(companies)
ttk.Combobox(c, textvariable=deliveryComp).grid(column='1',row='1')
for item in data:
    for i in item['orders']['order']:
        lbox.insert(END, i['title']+'\t|'+item['buyer_nick'])
        countrynames.append(i['title'])
        
    
lbl = ttk.Label(c, text="Send to country's leader:")
g1 = ttk.Radiobutton(c, text=gifts['card'], variable=gift, value='card');
g2 = ttk.Radiobutton(c, text=gifts['flowers'], variable=gift, value='flowers');
g3 = ttk.Radiobutton(c, text=gifts['nastygram'], variable=gift, value='nastygram');
send = ttk.Button(c, text='Send Gift', command=scanBarcode, default='active')
sentlbl = ttk.Label(c, textvariable=sentmsg, anchor='center');
status = ttk.Label(c, textvariable=statusmsg, anchor=W);

# Grid all the widgets
lbox.grid(column=0, row=1, rowspan=6, sticky=(N,S,E,W))
# lbl.grid(column=1, row=1, padx=10, pady=5)
# g1.grid(column=1, row=2, sticky=W, padx=20)
# g2.grid(column=1, row=3, sticky=W, padx=20)
# g3.grid(column=1, row=4, sticky=W, padx=20)
# send.grid(column=2, row=5, sticky=E)
# sentlbl.grid(column=1, row=6, columnspan=2, sticky=N, pady=5, padx=5)
# status.grid(column=0, row=7, columnspan=2, sticky=(W,E))
c.grid_columnconfigure(0, weight=1)
c.grid_rowconfigure(5, weight=1)

# Set event bindings for when the selection in the listbox changes,
# when the user double clicks the list, and when they hit the Return key
lbox.bind('<<ListboxSelect>>', showDetail)
#lbox.bind('<Double-1>', sendGift)
#root.bind('<Return>', sendGift)	

# Colorize alternating lines of the listbox
#for i in range(0,len(countrynames),2):
#    lbox.itemconfigure(i, background='#f0f0ff')

# Set the starting state of the interface, including selecting the
# default gift to send, and clearing the messages.  Select the first
# country in the list; because the <<ListboxSelect>> event is only
# generated when the user makes a change, we explicitly call showPopulation.
gift.set('card')
sentmsg.set('')
statusmsg.set('')
lbox.selection_set(0)
#showPopulation()

root.mainloop()
